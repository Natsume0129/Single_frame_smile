# 在另一台电脑上运行笑容时序分类实验

本包包含现成的逐帧 smile ranking 分数、固定的片段级划分，以及用于比较的基准预测。在五位已有参与者的 1,215 段 onset→peak 片段上，可用它重跑固定长度和变长时序分类实验，也可读取同一批特征训练自己的分类器。当前快照包含 26,680 张有效追踪帧，训练、验证、测试集分别有 879、159、177 段。

对应代码仓库为 [Single_frame_smile](https://github.com/Natsume0129/Single_frame_smile/tree/788e1794c406ce3baa3c7541cf339ad771dcfead)，打包使用的提交为 `788e179`。

## 1. 解压到哪里

在新电脑拉取仓库后，把 ZIP **直接解压到仓库根目录**，也就是同时能看到 `README.md` 和 `experiments/` 的那一层。解压后应当直接得到下列路径。若解压软件自动创建了名为 `smile_temporal_inputs_20261110` 的外层文件夹，把其中的 `output` 放到仓库根目录。

```text
output/
  single_frame_phase_classification_20261105/
    dataset.npz
    frame_metadata.json
    protocol.json
  three_class_curve_classifier_20261102/
    feature_manifest.json
  regional_ranking_extension_20261103/
    classifier/
      test_predictions.json
```

## 2. 三组文件各有什么用

| 文件组 | 读取方式与用途 |
|---|---|
| 逐帧分数 | `dataset.npz` 的 `X` 是一个 26,680 × 18 的数组。第 i 行对应 `frame_metadata.json` 中 `row_id == i` 的追踪帧。`protocol.json` 的 `feature_space_definitions["18d"]` 给出实际列序。6 个区域各有该参与者的 true、bitter、polite 三个模型的分数。|
| 片段清单与固定划分 | `feature_manifest.json` 每段一条记录。用帧记录的 `clip_id` 对接清单的 `id`，用 `clip_seconds` 排序，从 onset 的 0 秒排到 peak，即得到 T × 18 的序列。清单还提供类别、时长、来源分组和 `split`。沿用 `split` 可与原实验按同一批 clip 比较。|
| 基准测试预测 | `test_predictions.json` 包含 177 段测试 clip。现有时序脚本在模型选择完成后按 `id` 对齐，读取 `prediction` 与原 73 维分类器逐段比较。训练新模型时应把这份文件留给最终评估。|

原视频和人脸图像都保存在原研究机器上。本包保留了参与者代号、类别及原视频路径等元数据。清单里的旧盘符用于追溯，时序分类器读取的是包内的数据文件，换电脑后可以直接运行。

## 3. 安装依赖并运行

下面是 Windows PowerShell 命令，从仓库根目录执行。原实验使用 Python 3.10.11 和 PyTorch 2.9.1（CUDA 12.8 构建）。以下安装命令适用于 CPU 复现；已有可用 CUDA 环境时，也可以使用匹配驱动的 PyTorch 2.9.1 构建。脚本自动选择可用的 CUDA 或 CPU，设备和软件版本可能影响运行时间及数值结果。

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\python.exe -m pip install numpy==2.2.6 scipy==1.15.3 scikit-learn==1.7.2 joblib==1.5.3 matplotlib==3.10.8
.\.venv\Scripts\python.exe -m pip install torch==2.9.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe experiments/person_smile/tensor_sequence_experiment_20261109.py
.\.venv\Scripts\python.exe experiments/person_smile/render_tensor_sequence_report_20261109.py
```

训练完成后打开 `output/tensor_sequence_classification_20261109/index.html`。同目录的 `report_data.json` 保存指标，`test_predictions.json` 保存新实验的逐段预测。脚本会保护已有的已完成实验；如该目录下已经存在 `report_data.json`，可在新的仓库副本里重复实验。

## 4. 核对文件

以下是 ZIP 中五个原始输入的 SHA-256。在 PowerShell 中可用 `Get-FileHash -Algorithm SHA256 -LiteralPath <文件路径>` 计算后比较。

| 文件 | SHA-256 |
|---|---|
| `output/single_frame_phase_classification_20261105/dataset.npz` | `79c8ac4c9df9a718919c8b61d0bfa72e860877117061aaac55f001393878bcb2` |
| `output/single_frame_phase_classification_20261105/frame_metadata.json` | `61db2fcdbccd6dee1f7adaf6aaf42bb2a7123bf8f5755b808b5c818e57fd6c47` |
| `output/single_frame_phase_classification_20261105/protocol.json` | `a360565a559fc9527bd5b20ab24a23c6dd6af041dde1b9caa7d6bf5d5141c3fa` |
| `output/three_class_curve_classifier_20261102/feature_manifest.json` | `760c1f8a2aa395a875fcefe3b0723fb73d20527dc56ca333f92f82a509c4f11a` |
| `output/regional_ranking_extension_20261103/classifier/test_predictions.json` | `50cc6a560f7e7fe835a054ed46fd45cdc4347e67270e3717f43cfe2f68a35524` |
